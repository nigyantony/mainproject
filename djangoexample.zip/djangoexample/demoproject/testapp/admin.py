from django.contrib import admin
from testapp.models import logins
from testapp.models import Register
from testapp.models import nurse
from testapp.models import doctors
from testapp.models import medicine
from testapp.models import equipment
from testapp.models import stock
from testapp.models import feedbacks
from testapp.models import question
# Register your models here.
class loginsAdmin(admin.ModelAdmin):
    list_display = ['username','password','role']
admin.site.register(logins,loginsAdmin)

class RegisterAdmin(admin.ModelAdmin):
    list_display = ['ids','Collegeid','Name','Designation','Dob','Email','Mobile']
admin.site.register(Register,RegisterAdmin)

class nurseAdmin(admin.ModelAdmin):
    list_display = ['ids','nurseid','name','gender','dob','email','address','mobile','qualification','experience','image']
admin.site.register(nurse,nurseAdmin)

class doctorsAdmin(admin.ModelAdmin):
    list_display = ['ids','doctorsid','name','gender','dob','email','address','mobile','qualification','experience','photo']
admin.site.register(doctors,doctorsAdmin)

class medicineAdmin(admin.ModelAdmin):
    list_display = ['medicineid','medicinename','suppliername','place','date','billno','quantity','amount']
admin.site.register(medicine,medicineAdmin)

class equipmentAdmin(admin.ModelAdmin):
    list_display = ['equipmentid','equipmentname','suppliername','place','date','billno','quantity','amount']
admin.site.register(equipment,equipmentAdmin)

class stockAdmin(admin.ModelAdmin):
    list_display = ['medicineid','medicinename','quantity','amount']
admin.site.register(stock,stockAdmin)

class feedbacksAdmin(admin.ModelAdmin):
    list_display = ['fimd','name','comment']
admin.site.register(feedbacks,feedbacksAdmin)

class questionAdmin(admin.ModelAdmin):
    list_display = ['ids','Collegeid','Name','did','question','response','status']
admin.site.register(question,questionAdmin)
