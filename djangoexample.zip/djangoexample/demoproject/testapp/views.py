from django.core.mail import send_mail
from django.http import HttpResponse
from django.shortcuts import render
# Create your views here.
from django.template import loader

from .models import logins, Register, nurse



def hello_view(request):
    return render(request,'index.html')
def log(request):
    return render(request,'login.html')
def reg(request):
    return render(request,'register.html')
def saw(request):
    return render(request,'admin/homepage.html')
def nur(request):
    return render(request,'admin/addnurse.html')
def doct(request):
    return render(request,'admin/adddoctor.html')
def docto(request):
    return render(request,'doctor/doctorhomepage.html')
def nurs(request):
    return render(request,'nurse/nursehomepage.html')
def users(request):
    return render(request,'users/patienthomepage.html')

def add(request):
     if request.method=='POST':
       collegid=request.POST.get('cid')
       fullname=request.POST.get('name')
       des=request.POST.get('desi')
       dateob=request.POST.get('dates')
       emails=request.POST.get('email')
       mobile=request.POST.get('mobile')
       passwords=request.POST.get('password')
       objs = logins()
       objs.username = collegid
       objs.password = passwords
       objs.role = des
       objs.save()
       obj=Register()
       obj.Collegeid=collegid
       obj.Name= fullname
       obj.Designation=des
       obj.Dob=dateob
       obj.Email=emails
       obj.Mobile=mobile
       obj.ids = objs
       obj.save()

       return render(request,'login.html')

     else:
         return render(request,'register.html')

def nursereg(request):
    if request.method=='POST':
        nursid=request.POST.get('nid')
        name=request.POST.get('name')
        gender=request.POST.get('gender')
        dob=request.POST.get('dates')
        email=request.POST.get('email')
        address=request.POST.get('address')
        mobile=request.POST.get('mobile')
        qualifi=request.POST.get('quai')
        experi=request.POST.get('experi')
        image=request.FILES['image']
        objs = logins()
        objs.username = email
        objs.password = email
        objs.role='nurse'
        objs.save()
        objec=nurse()
        objec.nurseid=nursid
        objec.name=name
        objec.gender= gender
        objec.dob=dob
        objec.email=email
        objec.address=address
        objec.mobile= mobile
        objec.qualification=qualifi
        objec.experience=experi
        objec.image=image
        objec.ids = objs
        objec.save()
        subject="Account created"
        message="account for demoproject is created\nlogindetails\n username:",objs.username,"\npassword:",objs.username
        frommail="admin's mail"
        send_mail(subject,message,frommail,[objs.username],fail_silently=False)

        return render(request, 'homepage.html')

    else:
         return render(request, 'addnurse.html')


def signin(request):
    if request.method == 'POST':
        username = request.POST.get('usern')
        password = request.POST.get('password')
        if (logins.objects.filter(username=username,password=password).exists()):
            log = logins.objects.filter(username=username,password=password)
            for value in log:
                userid = value.id
                usertype = value.role
                if usertype=='nurse':
                    Role=request.session['Role']='nurse'
                    return render(request,'nurse/nursehomepage.html',{'user': Role, 'id': userid})
                elif usertype=='admin':
                    Role = request.session['Role'] = 'admin'
                    return render(request, 'admin/homepage.html',{'user': Role, 'id': userid})
                elif usertype=='doctor':
                    Role = request.session['Role'] = 'doctor'
                    return render(request, 'doctor/doctorhomepage.html',{'user': Role, 'id': userid})
                elif usertype=='student':
                    Role = request.session['Role'] = 'student'
                    return render(request, 'users/patienthomepage.html',{'user': Role, 'id': userid})
                elif usertype=='faculty':
                    Role = request.session['Role'] = 'faculty'
                    return render(request, 'users/patienthomepage.html',{'user': Role, 'id': userid})
                else:
                    context = {"error":"Incorrect Username"}
                    return render(request, 'index.html')
        else:
            templates=loader.get_template(template("login.html"))
            context = {"error": "Incorrect Information"}
            return  HttpResponse(templates.render(context,request))

    else:
        templates = loader.get_template(template("login.html"))
        context = {}
        return HttpResponse(Template.render(context, request))
