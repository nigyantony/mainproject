from django.contrib.auth import logout
from django.core.mail import send_mail
from django.db import connection
from django.http import HttpResponse, request
from django.shortcuts import render, redirect
# Create your views here.
from django.template import loader, Context

from .models import logins, Register, nurse, doctors, stock, medicine, equipment, feedbacks, question


def hello_view(request):
    return render(request,'index.html')
def log(request):
    return render(request,'login.html')
def reg(request):
    return render(request,'register.html')
def saw(request):
    return render(request,'admin/homepage.html')
def nur(request):
    return render(request,'admin/addnurse.html')
def doc(request):
    return render(request,'admin/adddoctor.html')
def docto(request):
    return render(request,'doctor/doctorhomepage.html')
def nurs(request):
    return render(request,'nurse/nursehomepage.html')
def users(request):
    return render(request,'users/patienthomepage.html')
def med(request):
    return render(request,'admin/medicineadd.html')
def equipadd(request):
    return render(request,'admin/equipmentadd.html')
def add(request):
     if request.method=='POST':
       collegid=request.POST.get('cid')
       fullname=request.POST.get('name')
       des=request.POST.get('desi')
       dateob=request.POST.get('dates')
       emails=request.POST.get('email')
       mobile=request.POST.get('mobile')
       passwords=request.POST.get('password')
       objs = logins()
       objs.username = collegid
       objs.password = passwords
       objs.role = des
       objs.save()
       obj=Register()
       obj.Collegeid=collegid
       obj.Name= fullname
       obj.Designation=des
       obj.Dob=dateob
       obj.Email=emails
       obj.Mobile=mobile
       obj.ids = objs
       obj.save()

       return render(request,'login.html')

     else:
         return render(request,'register.html')

def nursereg(request):
    if request.method=='POST':
        nursid=request.POST.get('nid')
        name=request.POST.get('name')
        gender=request.POST.get('gender')
        dob=request.POST.get('dates')
        email=request.POST.get('email')
        address=request.POST.get('address')
        mobile=request.POST.get('mobile')
        qualifi=request.POST.get('quai')
        experi=request.POST.get('experi')
        image=request.FILES['image']
        objs = logins()
        objs.username = email
        objs.password = email
        objs.role='nurse'
        objs.save()
        objec=nurse()
        objec.nurseid=nursid
        objec.name=name
        objec.gender= gender
        objec.dob=dob
        objec.email=email
        objec.address=address
        objec.mobile= mobile
        objec.qualification=qualifi
        objec.experience=experi
        objec.image=image
        objec.ids = objs
        objec.save()
        subject="Account created"
        message="account for demoproject is created\nlogindetails\n username:",objs.username,"\npassword:",objs.username
        frommail="nigyantony96@gmail.com"
        send_mail(subject,message,frommail,[objs.username],fail_silently=False)
        return render(request, 'homepage.html')

    else:
         return render(request, 'addnurse.html')

def doct(request):
    if request.method == 'POST':
        doctorid=request.POST.get('doid')
        name=request.POST.get('name')
        gender=request.POST.get('gender')
        dob=request.POST.get('dates')
        email=request.POST.get('email')
        address=request.POST.get('address')
        mobile=request.POST.get('mobile')
        qualification=request.POST.get('quali')
        experience=request.POST.get('experi')
        image_doc=request.FILES['image']
        objs = logins()
        objs.username = email
        objs.password = email
        objs.role='doctor'
        objs.save()
        objt=doctors()
        objt.doctorsid=doctorid
        objt.name=name
        objt.gender=gender
        objt.dob=dob
        objt.email=email
        objt.address=address
        objt.mobile=mobile
        objt.qualification=qualification
        objt.experience=experience
        objt.photo=image_doc
        objt.ids=objs
        objt.save()
        subject = "Account created"
        message = "account for demoproject is created\nlogindetails\n username:", objs.username, "\npassword:", objs.username
        frommail = "nigyantony96@gmail.com"
        send_mail(subject, message, frommail, [objs.username], fail_silently=False)
        return render(request, 'homepage.html')

    else:
        return render(request, 'adddoctor.html')

def signin(request):
    if request.method == 'POST':
        username = request.POST.get('usern')
        password = request.POST.get('password')
        if (logins.objects.filter(username=username,password=password).exists()):
            log = logins.objects.filter(username=username,password=password)
            for value in log:
                userid = value.id
                request.session['mid'] = userid
                print(userid)
                usertype = value.role
                if usertype=='nurse':
                    Role=request.session['mid']
                    return render(request,'nurse/nursehomepage.html',{'user': Role, 'id': userid})
                elif usertype=='admin':
                    #Role = request.session['mid'] = userid
                    return render(request, 'admin/homepage.html')
                elif usertype=='doctor':
                    Role = request.session['mid']
                    #request.session['mid'] = userid
                   # print(request.session['mid'])
                    #return render(request, 'doctor/doctorhomepage.html',{'user': Role, 'id': userid})
                    return render(request, 'doctor/doctorhomepage.html', {'user': userid, 'id': userid})
                elif usertype=='student':
                    Role = request.session['mid']
                    return render(request, 'users/patienthomepage.html',{'user': Role, 'id': userid,'key':userid})
                elif usertype=='faculty':
                    Role = request.session['mid']
                    return render(request, 'users/patienthomepage.html',{'user': Role, 'id': userid,'key':userid})
                else:
                    context = {"error":"Incorrect Username and Password"}
                    return render(request, "index.html",context)
        else:
            context = {"error": "Incorrect Username and Password"}
            return render(request, "login.html", context)

    else:
        templates = loader.get_template("login.html")
        context = {}
        return HttpResponse(templates.render(context, request))

def signout(request):
    del request.session['mid']
    logout(request)
    return redirect('index')
def medic(request):
    if request.method == 'POST':
        medid = request.POST.get('mid')
        medicinenames=request.POST.get('mname')
        suppliernames=request.POST.get('sname')
        places=request.POST.get('place')
        datet=request.POST.get('dates')
        billnos=request.POST.get('billno')
        quantitys=request.POST.get('quant')
        amounts=request.POST.get('amount')
        objm=medicine()
        objm.medicineid=medid
        objm.medicinename=medicinenames
        objm.suppliername=suppliernames
        objm.place=places
        objm.date=datet
        objm.billno=billnos
        objm.quantity=quantitys
        objm.amount=amounts
        objm.save()
        objc = stock()
        objc.medicineid = medid
        objc.medicinename = medicinenames
        objc.quantity = quantitys
        objc.amount = amounts
        #objc.idm  =objm
        objc.save()
        return render(request, 'admin/homepage.html')

    else:
        return render(request, 'medicineadd.html')


def equp(request):
    if request.method == 'POST':
        equid=request.POST.get('eid')
        eqname=request.POST.get('ename')
        suppname=request.POST.get('suname')
        place=request.POST.get('place')
        date=request.POST.get('dates')
        bino=request.POST.get('billno')
        quanti=request.POST.get('quants')
        amout=request.POST.get('amot')
        obts=equipment()
        obts.equipmentid=equid
        obts.equipmentname=eqname
        obts.suppliername=suppname
        obts.place=place
        obts.date=date
        obts.billno=bino
        obts.quantity=quanti
        obts.amount=amout
        obts.save()
        return render(request, 'admin/homepage.html')

    else:
        return render(request, 'equipmentadd.html')

def pofiles(request,id):
    data=Register.objects.get(ids_id=id)
    return render(request,'users/profileview.html',{'data':data})
def edit(request,id):
    if request.method == 'POST':
        data = Register.objects.get(ids_id=id)
        collegid = request.POST.get('cid')
        fullname = request.POST.get('name')
        des = request.POST.get('desi')
        emails = request.POST.get('email')
        mobile = request.POST.get('mobile')
        data.Collegeid=collegid
        data.Name=fullname
        data.Designation=des
        data.Email=emails
        data.Mobile=mobile
        data.save()
        return render(request,'users/patienthomepage.html',{'key':data.ids_id})
def nurseprofi(request,id):
    data=Register.objects.get(ids_id=id)
    return render(request,'nurse/nursepofile.html',{'data':data})
def feed(request,id):
    data=Register.objects.get(ids_id=id)
    return render(request,'users/feedback.html',{'data':data})
def feedbak(request,id):
    if request.method == 'POST':
        #key=request.session['Role']
        data=Register.objects.get(ids_id=id)
        obts = feedbacks()
        obts.name=data.Name
        comment=request.POST.get('comments')
        obts.comment=comment
        obts.fimd=data.ids_id
        key=obts.fimd
        obts.save()
        return render(request,'users/patienthomepage.html',{'key':key})
def feedbackuser(request):
    data=Register.objects.all()
    data1=feedbacks.objects.all()
    return render(request,'admin/feedbackuser.html',{'data':data,'data1':data1})
def viewnurse(request):
    data=nurse.objects.all()
    return render(request,'admin/nurselist.html',{'data':data})
def viewmedicine(request):
    data=medicine.objects.all()
    return render(request,'admin/medicinelist.html',{'data':data})
def viewequip(request):
    data=equipment.objects.all()
    return render(request,'admin/equipmentlist.html',{'data':data})
def viewdoctor(request):
    data=doctors.objects.all()
    return render(request,'admin/doctorslist.html',{'data':data})
def questi(request):
    data=doctors.objects.all()
    return render(request,'users/questions.html',{'data':data})
def questo(request):
     if request.method=='POST':
        rid=request.session['mid']
        data=Register.objects.get(ids=rid)
        data1 = logins.objects.get(id=rid)
        did=request.POST.get('doctor')
        data2=doctors.objects.get(id=did)
        qu=request.POST.get('questions')
        obst=question()
        obst.did=data2
        obst.question=qu
        obst.Collegeid=data.Collegeid
        obst.Name=data.Name
        obst.response=''
        obst.status=''
        obst.ids=data1
        obst.save()
        return render(request,'users/patienthomepage.html')
def prodel(request,id):
    if (doctors.objects.filter(id=id).exists()):
        data = doctors.objects.get(id=id)
        data2=logins.objects.get(username=data.email)
        data2.delete()
        data.delete()
        return render(request, 'admin/homepage.html')
    else:
        return render(request, 'admin/doctorslist.html')
def pp(request,id):
    if (nurse.objects.filter(id=id).exists()):
        data = nurse.objects.get(id=id)
        data2=logins.objects.get(username=data.email)
        data2.delete()
        data.delete()
        return render(request, 'admin/homepage.html')
    else:
        return render(request, 'admin/nurselist.html')
def medde(request,id):
    if (medicine.objects.filter(id=id).exists()):
        data = medicine.objects.get(id=id)
        data2=stock.objects.get(id=data.id)
        data2.delete()
        data.delete()
        return render(request, 'admin/homepage.html')
    else:
        return render(request, 'admin/medicinelist.html')
def eqdde(request,id):
    if (equipment.objects.filter(id=id).exists()):
        data = equipment.objects.get(id=id)
        data.delete()
        return render(request, 'admin/homepage.html')
    else:
        return render(request, 'admin/equipmentlist.html')
def questlist(request):
    data=question.objects.all()
    data1=doctors.objects.all()
    return render(request,'admin/question.html',{'data':data,'data1':data1})
def approve(request,id):
    data=question.objects.get(id=id)
    data.status='Approved'
    data.save()
    return render(request,'admin/homepage.html',{'data':data})
def reject(request,id):
    data = question.objects.get(id=id)
    data.status = 'Rejected'
    data.save()
    return render(request, 'admin/homepage.html', {'data': data})

#function to convert into dict

def dictfetchall(cursor):
    """Return all rows from a cursor as a dict"""
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]

# view for sending response
def response_view(request):

    print("inside response view")

    x=(request.session.get('mid'))
    print (x)

    cursor = connection.cursor()
    cursor.execute("""
    
    select 
    testapp_question.Collegeid,testapp_question.Name,testapp_question.question from testapp_question 
    left outer join testapp_doctors
    on
    (testapp_question.did_id=testapp_doctors.id)
    where testapp_doctors.ids_id=%d  """%(x))

    dict = {}
    dict = dictfetchall(cursor)
    print(dict)
    context = {
        'dict': dict
    }
    #print (dict)
    return render(request,'doctor/studqestions.html',context)


