from django.shortcuts import render

# Create your views here.
def hello_view(request):
    return render(request,'index.html')
def log(request):
    return render(request,'login.html')