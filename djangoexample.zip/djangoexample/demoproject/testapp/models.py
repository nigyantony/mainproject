from django.db import models
# Create your models here.
class Register(models.Model):
      Collegeid=models.AutoField(primary_key=True,max_length=50)
      Name=models.CharField(max_length=50)
      Designation=models.CharField(max_length=50)
      Email=models.EmailField()
      Mobile=models.CharField(max_length=50)
      Dob=models.DateField()