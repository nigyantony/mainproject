from django.db import models
# Create your models here.
class logins(models.Model):
      username=models.CharField(max_length=50)
      password=models.CharField(max_length=50)
      role=models.CharField(max_length=50)
class Register(models.Model):
 ids=models.ForeignKey(logins,on_delete=models.CASCADE)
 Collegeid=models.CharField(unique=True,max_length=30)
 Name=models.CharField(max_length=50)
 Designation=models.CharField(max_length=50)
 Dob = models.DateField()
 Email=models.EmailField()
 Mobile=models.CharField(max_length=50)
class nurse(models.Model):
    ids = models.ForeignKey(logins, on_delete=models.CASCADE)
    nurseid=models.CharField(unique=True,max_length=30)
    name=models.CharField(max_length=50)
    gender=models.CharField(max_length=30)
    dob=models.DateField()
    email=models.EmailField()
    address=models.CharField(max_length=100)
    mobile=models.CharField(max_length=50)
    qualification=models.CharField(max_length=30)
    experience=models.CharField(max_length=30)
    image=models.ImageField(upload_to='images')
#class doctor(models.Model):
